package metodus;

public class Jatek_met_02 {
    
    static int hElet, vElet;
    static final String TAB = "  ";
    
    public static void main(String[] args) {
               
        kezdes("3 körös játék");      
        for (int i = 0; i < 3; i++) {
            jatekMenet_V1(i);
        }
        
        
        kezdes("\n----------\nHalálig tartó játék");
        int korDB = 0;
        while (hElet > 0 && vElet > 0) {
            jatekMenet_V2(korDB);
            korDB++;
        }
    }

    private static void jatekMenet_V2(int korDB) {
        //kor++;
        System.out.println(++korDB + ". kör");
        int hHely = (int)(Math.random()*3);
        int vHely = (int)(Math.random()*3);
        if(hHely == vHely){
            System.out.println(TAB + "HARC:");
            int dobas = (int)(Math.random()*6)+1;
            hElet -= dobas;
            dobas = (int)(Math.random()*6)+1;
            vElet -= dobas;
        }else{
            System.out.println(TAB + "KALANDOZÁS:");
        }
        System.out.printf("%sH:%d V:%d\n", TAB, hElet, vElet);
    }

    private static void jatekMenet_V1(int i) {
        System.out.println((i+1) + ". kör");
        int hHely = (int)(Math.random()*3);
        int vHely = (int)(Math.random()*3);
        if(hHely == vHely){
            System.out.println(TAB + "HARC:");
            int dobas = (int)(Math.random()*6)+1;
            hElet -= dobas;
            dobas = (int)(Math.random()*6)+1;
            vElet -= dobas;
        }else{
            System.out.println(TAB + "KALANDOZÁS:");
        }
        System.out.printf("%sH:%d V:%d\n", TAB, hElet, vElet);
    }
   
    private static void kezdes(String jatekTipusa) {
        hElet = 9;
        vElet = 9;
        System.out.println(jatekTipusa);
        System.out.println("KEZDÉS:");
        System.out.printf("%sH:%d V:%d\n", TAB, hElet, vElet);
    }
    
}
